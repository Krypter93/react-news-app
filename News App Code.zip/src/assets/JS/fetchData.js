//API URL
const url = "https://ok.surf/api/v1/cors/news-feed";

export async function fetchData() {
  try {
    const resp = await fetch(url);
    if (!resp.ok) {
      throw new Error("Failed to fetch data");
    }
    const data = await resp.json();
    return data;
  } catch (err) {
    console.log(err);
    throw err;
  }
}
