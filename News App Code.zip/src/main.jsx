import React from "react";
import ReactDOM from "react-dom/client";
import { News } from "./components/News";
import { About } from "./components/About";
import { ErrorPage } from "./components/ErrorPage";
import { createBrowserRouter, RouterProvider } from "react-router-dom";

//Definición de página principal para githubpages:
const basename = process.env.NODE_ENV === "production" ? "/react-news-app" : "/";

const router = createBrowserRouter(
  [
    {
      path: "/",
      element: <News />,
    },
    {
      path: "/about",
      element: <About />,
    },
    {
      path: "*",
      element: <ErrorPage />,
    },
  ],
  { basename: basename }
);

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
