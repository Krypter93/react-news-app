import "../assets/css/navbar.css";
import { Link } from "react-router-dom";

export function Navbar() {
  return (
    <>
      <div className="container">
        <h1>News App</h1>
        <div className="menu">
          <ul>
            <li>
              <Link to={"/"} className="li">
                Home
              </Link>
            </li>

            <li>
              <Link to={"/about"} className="li">
                About
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
}
