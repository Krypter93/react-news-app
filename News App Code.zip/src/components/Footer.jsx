import "../assets/css/footer.css";

export function Footer() {
  return (
    <>
      <div className="footer-container">
        <p className="copy"> &copy; All rights reserved </p>
        <p className="author">Developed by: Krypter93</p>
      </div>
    </>
  );
}
