import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import "../assets/css/error.css";

export function ErrorPage() {
  return (
    <>
      <Navbar />

      <div className="error-container">
        <div className="info">
          <h1>Oops!</h1>
          <p>Sorry, we can't find that page ☹️ </p>
        </div>
      </div>

      <Footer />
    </>
  );
}
