import "../assets/css/card.css";
import PropTypes from "prop-types";

export function Card({ news }) {
  return (
    <>
      <div className="card-container">
        <h1>Top US Headlines</h1>

        <div className="cards">
          {news.map((item) => {
            return (
              <div className="data-card" key={item.index}>
                <img src={item.og} />
                <h3> {item.title} </h3>
                <p> Source: {item.source} </p>
                <a href={item.link} target="_blank">
                  <button> Read More... </button>
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

Card.propTypes = {
  news: PropTypes.array.isRequired,
};
