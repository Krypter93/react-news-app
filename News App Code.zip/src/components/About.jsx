import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import "../assets/css/about.css";
import { FaFacebook } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { GrGithub } from "react-icons/gr";
import { FaInstagram } from "react-icons/fa";
import { IoIosMail } from "react-icons/io";

export function About() {
  return (
    <>
      <Navbar />

      <div className="about-container">
        <div className="about-card">
          <h2>Description</h2>
          <p>
            Our application delivers real-time top headlines from the United
            States, curated from various reliable sources. Stay informed with
            the latest updates across different categories such as sports,
            entertainment, technology and general news. Explore diverse
            perspectives and stay connected with what's happening in the US, all
            in one place.
          </p>

          <div className="contact">
            <h3>Contact Developer:</h3>
            <div id="links">
              <span>
                <a href="https://www.facebook.com/ahmedfdezx2" target="_blank">
                  {" "}
                  <FaFacebook />{" "}
                </a>
              </span>
              <span>
                <a href="https://twitter.com/ahmedfdezx2" target="_blank">
                  {" "}
                  <FaXTwitter />{" "}
                </a>
              </span>
              <span>
                <a href="https://github.com/Krypter93" target="_blank">
                  {" "}
                  <GrGithub />{" "}
                </a>
              </span>
              <span>
                <a
                  href="https://www.instagram.com/ahmedfdezx2/"
                  target="_blank"
                >
                  {" "}
                  <FaInstagram />{" "}
                </a>
              </span>
              <span>
                <a href="mailto:ahmedfdez93@gmail.com">
                  {" "}
                  <IoIosMail />{" "}
                </a>
              </span>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
