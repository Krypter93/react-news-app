import { useState } from "react";
import { Card } from "./Card";
import { fetchData } from "../assets/JS/fetchData.js";
import useAsyncEffect from "use-async-effect";
import { Navbar } from "./Navbar.jsx";
import { Footer } from "./Footer.jsx";

export function News() {
  const [news, setNews] = useState([]);

  useAsyncEffect(async () => {
    const data = await fetchData();
    const dataFetched = data.Business.map((item, index) => {
      return {
        index,
        og: item.og,
        title: item.title,
        source: item.source,
        link: item.link,
      };
    });
    setNews(dataFetched);
  }, []);

  return (
    <>
      <Navbar />
      <Card news={news} />
      <Footer />
    </>
  );
}
